<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Responsable del LIEE</title>

    <!-- Custom fonts for this template-->
    <link href="{{ asset('INAOE template\vendor\fontawesome-free\css\all.css') }}" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- CSS -->
    <link href="{{ asset('INAOE template/css/respLIEE.css') }}" rel="stylesheet">
    
</head>

<body id="page-top">

    <!-- Contenido - Inicio -->
    <div id="wrapper">

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
            <div class="container">              
                <h1>Análisis de Factibilidad</h1>
                <form action="{{ route('upload') }}" method="post" enctype="multipart/form-data">

                    <!-- Factible -->
                    <div class="form-group">
                        <div class="checkbox-wrapper-46">
                            <input type="checkbox" id="cbx-46" class="inp-cbx" name="factible">
                            <label for="cbx-46" class="cbx">
                                <span>
                                    <svg viewBox="0 0 12 10" height="10px" width="12px">
                                        <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                    </svg>
                                </span>
                                <span>Factible</span>
                            </label>
                        </div>
                        <br><br>
                        <div class="factible-options" style="display: none;">
                            Documento de Factibilidad:
                            <br>
                            <input type="file" name="factibilidad_file" accept=".pdf">
                            <br><br>
                            <button type="submit"><span>Aceptar</span></button>
                        </div>
                    </div>
                    <br>
                    <!-- Cotización -->
                    <div class="form-group">
                        <div class="checkbox-wrapper-46">
                            <input type="checkbox" id="cbx-47" class="inp-cbx" name="cotizacion">
                            <label for="cbx-47" class="cbx">
                                <span>
                                    <svg viewBox="0 0 12 10" height="10px" width="12px">
                                        <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                    </svg>
                                </span>
                                <span>Cotización</span>
                            </label>
                        </div>
                        <br><br>
                        <div class="cotizacion-options" style="display: none;">
                            Documento de cotización:
                            <br>
                            <input type="file" name="cotizacion_file" accept=".pdf">
                            <br><br>
                            <button type="submit"><span>Aceptar</span></button>
                        </div>
                    </div>
                    <br>
                    <!-- Aceptación del cliente -->
                    <div class="form-group">
                        <div class="checkbox-wrapper-46">
                            <input type="checkbox" id="cbx-48" class="inp-cbx" name="servicio">
                            <label for="cbx-48" class="cbx">
                                <span>
                                    <svg viewBox="0 0 12 10" height="10px" width="12px">
                                        <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                    </svg>
                                </span>
                                <span>Aceptación del cliente</span>
                            </label>
                        </div>
                        <br><br>
                        <div class="servicio-options" style="display: none;">
                            Documento del servicio:
                            <br>
                            <input type="file" name="servicio_file" accept=".pdf">
                            <br><br>
                            <button type="submit"><span>Aceptar</span></button>
                        </div>
                    </div>
                    <br>
                    <!-- Notificar al personal -->
                    <div class="form-group">
                        <div class="checkbox-wrapper-46">
                            <input type="checkbox" id="cbx-49" class="inp-cbx" name="notificar_personal">
                            <label for="cbx-49" class="cbx">
                                <span>
                                    <svg viewBox="0 0 12 10" height="10px" width="12px">
                                        <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                    </svg>
                                </span>
                                <span>Notificar al personal</span>
                            </label>
                        </div>
                    </div>
                    <br>
                    <!-- Subir Facturación del Cliente -->
                    <div class="form-group">
                        Subir Facturación del Cliente:
                        <input type="file" name="facturacion_cliente_file" accept=".pdf">
                        <button type="submit">Subir Factura</button>
                    </div>

                </form>
                
                <!-- Cerrar Sesión -->
                <ul class="nav justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Cerrar Sesión</a>
                    </li>
                </ul>

                <!-- Agregar Usuario -->
                <ul class="nav justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="{{ url('/registroPersonal') }}">Agregar Usuario</a>
                    </li>
                </ul>                
            </div>
                <!-- End of Main Content -->
                
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- Final - Contenido -->

    <script>
        // JavaScript para mostrar/ocultar opciones al hacer clic en los checkboxes
        document.querySelectorAll('input[type="checkbox"]').forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                var option = this.parentNode.parentNode.querySelector('.' + this.name + '-options');
                if (this.checked) {
                    option.style.display = 'block';
                } else {
                    option.style.display = 'none';
                }
            });
        });
    </script>

</body>

</html>