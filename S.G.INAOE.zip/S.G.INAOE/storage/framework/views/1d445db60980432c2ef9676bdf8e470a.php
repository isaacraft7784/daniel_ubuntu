<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Servicio</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
    </style>
</head>
<body>
    <h2>Datos del Cliente</h2>
    <form action="<?php echo e(url('/guardar-cliente')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <table>
            <tbody>
                <tr>
                    <td>Nombre de contacto:</td>
                    <td><input type="text" name="nombre_contacto" required></td>
                    <td>Razón Social:</td>
                    <td><input type="text" name="razon_social" required></td>
                </tr>
                <tr>
                    <td>Dirección:</td>
                    <td><input type="text" name="direccion" required></td>
                    <td>RFC:</td>
                    <td><input type="text" name="rfc" required></td>
                </tr>
                <tr>
                    <td>Teléfono:</td>
                    <td><input type="tel" name="telefono" required></td>
                    <td>E-mail:</td>
                    <td><input type="email" name="email" required></td>
                </tr>
            </tbody>
        </table>

        <button type="submit">Guardar Cambios</button>
    </form>


    <h2>Ensayos</h2>
    <table>
        <thead>
            <tr>
                <th>Tipo</th>
                <th>Código</th>
                <th>NOM 030 ENER 2016</th>
                <th>Elegir Servicio</th>
                <th>Tipo</th>
                <th>Código</th>
                <th>NOM 031 ENER 2019</th>
                <th>Elegir Servicio</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>A</td>
                <td>030/7.1</td>
                <td>Eficacia luminosa</td>
                <td><input type="checkbox"></td>
                <td>A*</td>
                <td>031/8.1</td>
                <td>Eficacia luminosa</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.2</td>
                <td>Variación del flujo luminoso total nominal</td>
                <td><input type="checkbox"></td>
                <td>A*</td>
                <td>031/8.2</td>
                <td>Variación de flujo luminoso nominal</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.3</td>
                <td>Temperatura de color correlacionada (TCC)</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.3</td>
                <td>Temperatura de color correlacionada (TCC)</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.4</td>
                <td>Flujo luminoso total mínimo mantenido</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.4</td>
                <td>Flujo luminoso total mínimo mantenido</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.5</td>
                <td>Índice de rendimiento de color (IRC)</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.5</td>
                <td>Índice de rendimiento de color (IRC)</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.6</td>
                <td>Factor de potencia (PU)</td>
                <td><input type="checkbox"></td>
                <td>A*</td>
                <td>031/8.6</td>
                <td>Factor de potencia (PU)</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.7</td>
                <td>Distribución espacial de luz</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.7</td>
                <td>Distorsión armónica total en corriente</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.8</td>
                <td>Ciclo de choque térmico</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.8</td>
                <td>Flujo luminoso de deslumbramiento</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.9</td>
                <td>Resistencia al choque térmico y a la conmutación</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.9</td>
                <td>Resistencia a las descargas atmosféricas</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>A</td>
                <td>030/7.10</td>
                <td>Distorsión armónica total</td>
                <td><input type="checkbox"></td>
                <td>A</td>
                <td>031/8.10</td>
                <td>N/A</td>
                <td><input type="checkbox"></td>
            </tr>
        </tbody>
    </table>
    <p style="margin-top: 20px;">
    <strong>A </strong>- Ensayo Acreditado. Laboratorio de Ensayo acreditado por ema, a.c. con acreditación No. EE-1242-051/20, No. de acreditación CONUEE: DG. E00.203.2022<br>
    <strong>A* - </strong>Acreditado conforme a NOM-031-ENER-2012 <strong>S/A </strong>- Ensayo no Acreditado
    </p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\S.G.INAOE\resources\views/solicitudServicio.blade.php ENDPATH**/ ?>