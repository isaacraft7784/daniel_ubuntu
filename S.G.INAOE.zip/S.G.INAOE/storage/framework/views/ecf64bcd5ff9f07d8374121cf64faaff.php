<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario PDF</title>
</head>
<body>
    <h2>Formulario para Generar PDF</h2>
    <form action="<?php echo e(route('solicitudServicios_pdf')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nombre_contacto">Nombre de Contacto:</label>
            <input type="text" name="nombre_contacto" id="nombre_contacto" required>
        </div>
        <div>
            <label for="razon_social">Razón Social:</label>
            <input type="text" name="razon_social" id="razon_social" required>
        </div>
        <div>
            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion">
        </div>
        <div>
            <label for="rfc">RFC:</label>
            <input type="text" name="rfc" id="rfc">
        </div>
        <div>
            <label for="telefono">Teléfono:</label>
            <input type="tel" name="telefono" id="telefono">
        </div>
        <div>
            <label for="email">E-mail:</label>
            <input type="email" name="email" id="email">
        </div>
        <div>
            <label>Servicios:</label><br>
            <input type="checkbox" name="servicios[]" value="030/7.1"> 030/7.1 - Eficacia luminosa.<br>
            <input type="checkbox" name="servicios[]" value="030/7.2"> 030/7.2 - Variación del flujo luminoso total nominal<br>
            <input type="checkbox" name="servicios[]" value="030/7.3"> 030/7.3 - Temperatura de color correlacionado (TCC)<br>
            <!-- Agrega más checkboxes según los servicios -->
        </div>
        <button type="submit">Generar PDF</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\alval\OneDrive\Documentos\BUAP\Proyecto\S.G.INAOE\resources\views/solicitudServicios.blade.php ENDPATH**/ ?>