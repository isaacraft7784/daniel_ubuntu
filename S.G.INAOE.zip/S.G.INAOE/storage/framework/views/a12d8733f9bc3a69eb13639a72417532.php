<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LIEE - Inicio</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('INAOE template\vendor\fontawesome-free\css\all.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- CSS -->
    <link href="<?php echo e(asset('INAOE template/css/sb-admin-2.css')); ?>" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Contenido - Inicio -->
    <div id="wrapper">

        <!-- Menú -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('/principal')); ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">LIEE INAOE <sup>VidaIT</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(url('/principal')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Inicio</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

           
            
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Extras
            </div>

            <!-- SUBMENÚ EXTRAS -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Personal LIEE</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Para personal del LIEE:</h6>
                        <a class="collapse-item" href="<?php echo e(url('/login')); ?>">Inicio de Sesión</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/responsableLIEE')); ?>">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Responsable LIEE</span></a>
            </li>

            
             <!-- Nav Item - Tables -->
             <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/encuesta')); ?>">
                    <i class="fas fa-smile"></i>
                    <span>Encuesta de Satisfacción</span></a>
            </li>




            

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- Fin del menú -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
            
                <!-- Contenido principal -->
                <div class="container-fluid">
                    <br>
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"></h1>
                        <a href="<?php echo e(url('/solicitudServicio')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i>  Solicitar servicio</a>
                                
                    </div>                    
                    <!-- BANCOS DE ENSAYO Y MEDICIÓN - INICIO -->

                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <h1 class="section-heading">Servicios</h1>
                                    <h4 class="section-subheading text-muted">BANCOS DE ENSAYO Y MEDICIÓN</h4>
                                    <br>
                                    <br>
                                </div>
                            </div>
                            <div class="row text-center">
                                <!-- ESFERA INTEGRADORA - INICIO -->                                
                                    <div class="col-md-4">
                                        <div class="fa-stack fa-4x" style="position: relative;">
                                            
                                        </div>
                                        <br><br>
                                        <a target="_blank" rel="nofollow" href="https://www.inaoep.mx/~liee/files/esfera.pdf"><h4>Esfera Integradora</h4></a>
                                        <p class="text-muted-justify">Esfera hueca de alta reflexión de 3m de diámetro que permite medir la potencia luminosa de una fuente de luz artificial así como otras características radiométricas y de eficiencia energética, tales como TCC, IRC, eficacia, FP y distorsión armónica.</p>
                                    </div>
                                <!-- FINAL - ESFERA INTEGRADORA -->
                                <!-- CHOQUE TÉRMICO - INICIO -->
                                    <div class="col-md-4">
                                        <div class="fa-stack fa-4x" style="position: relative;">
                                            
                                        </div>
                                        <br><br>
                                        <a target="_blank" rel="nofollow" href="https://www.inaoep.mx/~liee/files/choque_termico.pdf"><h4 class="service-heading">Choque térmico</h4></a>
                                        <p class="text-muted-justify">Es un equipo para ensayos de envejecimiento acelerado, consta de dos cámaras térmicas entre las cuales se desplaza automáticamente una canastilla que transporta objetos bajo prueba para someterlas a choque térmico de entre -10 °C y 50 °C. Permite configurar diferentes ciclos y tiempos de exposición.</p>
                                    </div>
                                <!-- FINAL - CHOQUE TÉRMICO -->
                                <!-- FOTOGONIÓMETRO - INICIO -->
                                    <div class="col-md-4">
                                        <div class="fa-stack fa-4x" style="position: relative;">
                                            
                                        </div>
                                        <br><br>
                                        <a target="_blank" rel="nofollow" href="https://www.inaoep.mx/~liee/files/fotogoniometro.pdf"><h4 class="service-heading">Fotogoniómetro</h4></a>
                                        <p class="text-muted-justify">Fotómetro de celda móvil automatizado cuya función es determinar el comportamiento espacial de intensidades luminosas de una fuente de luz artificial. Está constituido por un brazo móvil de 6m con doble sensor de iluminancia y un soporte móvil para especímenes.</p>
                                    </div>
                                <!-- FINAL - FOTOGONIÓMETRO -->
                            </div>
                            <br><br>
                            <div class="row text-center">
                                <!-- SOBRETENSONES - INICIO -->                                
                                    <div class="col-md-4">
                                        <div class="fa-stack fa-4x" style="position: relative;">
                                            
                                        </div>
                                        <br><br>
                                        <a target="_blank" rel="nofollow" href="https://www.inaoep.mx/~liee/files/sobretensiones.pdf"><h4 class="service-heading">Sobretensiones Transitorias</h4></a>
                                        <p class="text-muted-justify">Banco de pruebas que permite aplicar a lámparas, componentes eléctricos y electrónicos sobretensiones transitorias amortiguadas de 0.5µs a una frecuencia de 100kHz y sobretensiones de impulso por rayo de hasta 6kV a 3kA con onda combinada de 1.2/50 µs, lo anterior evalúa su confiabilidad ante fallos en la red eléctrica.</p>
                                    </div>
                                <!-- FINAL - SOBRETENSIONES -->
                                <!-- CONMUTACIÓN - INICIO -->                               
                                    <div class="col-md-4">
                                    <div class="fa-stack fa-4x" style="position: relative;">
                                            
                                        </div>
                                        <br><br>
                                        <a target="_blank" rel="nofollow" href="https://www.inaoep.mx/~liee/files/conmutacion.pdf"><h4 class="service-heading">Ciclo de Conmutación</h4></a>
                                        <p class="text-muted-justify">Sistema electrónico automatizado con control por computadora que tiene por objetivo ejecutar ensayos de envejecimiento acelerado a lámparas y luminarios, a través de ciclos automatizados de encendido y apagado, monitoreando su corriente de carga para verificar su condición de funcionamiento.</p>
                                    </div>
                                <!-- FINAL - CONMUTACIÓN -->
                                <!-- SALUD VISUAL - INICIO -->
                                    <div class="col-md-4">
                                    <div class="fa-stack fa-4x" style="position: relative;">
                                            
                                        </div>
                                        <br><br>
                                        <a target="_blank" rel="nofollow" href="https://www.inaoep.mx/~liee/files/Doc025stps.pdf"><h4 class="service-heading">Salud Visual</h4></a>
                                        <p class="text-muted-justify">Objetivo del servicio: Realizar el estudio y evaluación de las condiciones de iluminación en el centro de trabajo para identificar áreas de oportunidad en la mejora del desempeño visual, evitando riesgos y demostrando cumplimiento de la norma NOM-025-STPS.</p>
                                    </div>
                                <!-- FINAL - SALUD VISUAL -->
                            </div>
                        </div>

                    <!-- FINAL - BANCOS DE ENSAYO Y MEDICIÓN -->                        

                </div>
                <!-- Fin contenido principal -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Todos los derechos reservados INAOE</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- Final - Contenido -->

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('INAOE template/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('INAOE template/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('INAOE template/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('INAOE template/js/sb-admin-2.min.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(asset('INAOE template/vendor/chart.js/Chart.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('INAOE template/js/demo/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('INAOE template/js/demo/chart-pie-demo.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\S.G.INAOE\resources\views/pagInicio.blade.php ENDPATH**/ ?>