<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\RegistroPersonalController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', function () {
    return view('pagInicio');
});

Route::get('/principal', function () {
    return view('pagInicio');
});

// Combina la ruta '/' e '/inicio' para que el url no cambie
// y redireccionar a la página principal sea entendible "{{ url('/principal') }}"
Route::get('/principal', function () {
    return redirect('/');
});

Route::get('/login', 'App\Http\Controllers\LoginController@showLoginForm')->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login');

Route::get('/responsableLIEE', function () {
    return view('responsableLIEE');
})->name('responsableLIEE');

Route::get('/rol2', function () {
    return view('rol2');
})->name('rol2');

Route::get('/rol3', function () {
    return view('rol3');
})->name('rol3');

Route::get('/rol4', function () {
    return view('rol4');
})->name('rol4');

Route::get('/login-error', function () {
    return view('login-error');
})->name('login-error');




Route::get('/tablas', function () {
    return view('Tablas');
});

Route::get('/solicitudServicio', function () {
    return view('solicitudServicio');
});

Route::get('/encuesta', function () {
    return view('encuesta');
});

// Ruta para mostrar el formulario de registro
Route::get('/registroPersonal', function () {
    return view('registroPersonal');
});

// Ruta para procesar el formulario de registro
Route::post('/registroPersonal', [RegistroPersonalController::class, 'registro'])->name('registroPersonal');

Route::post('/guardar-cliente', [ClienteController::class, 'guardarCliente']);

Route::post('/upload', 'LIEEcontroller@upload')->name('upload');
