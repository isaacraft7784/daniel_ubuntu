<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Personal;
use Illuminate\Support\Facades\Hash;

class RegistroPersonalController extends Controller
{
    /**
     * Muestra el formulario de registro.
     *
     * @return \Illuminate\View\View
     */
    public function showRegistroForm()
    {
        return view('registroPersonal');
    }

    /**
     * Procesa el formulario de registro y crea un nuevo usuario en la base de datos.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function registro(Request $request)
{
    // Valida los datos del formulario
    $request->validate([
        'id_rol' => 'required',
        'nombre' => 'required',
        'apellido_paterno' => 'required',
        'apellido_materno' => 'required',
        'correo_electronico' => 'required|email|max:40|unique:personal,correo_electronico',
        'password' => 'required|min:6',
    ]);

    // Crea un nuevo usuario en la base de datos
    $usuario = new Personal();
    $usuario->id_rol = $request->id_rol;
    $usuario->nombre = $request->nombre;
    $usuario->apellido_paterno = $request->apellido_paterno;
    $usuario->apellido_materno = $request->apellido_materno;
    $usuario->correo_electronico = $request->correo_electronico;
    $usuario->password = bcrypt($request->password); // Hash the password using bcrypt
    $usuario->save();

    // Redirige a la página de inicio o a donde desees
    return view('responsableLIEE');
}
}
