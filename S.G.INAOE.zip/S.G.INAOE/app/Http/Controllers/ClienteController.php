<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;

class ClienteController extends Controller
{
    public function guardarCliente(Request $request)
    {
        // Validar los datos del formulario si es necesario

        $cliente = new Cliente();
        $cliente->nombre_responsable = $request->input('nombre_contacto');
        $cliente->razon_social = $request->input('razon_social');
        $cliente->direccion = $request->input('direccion');
        $cliente->rfc = $request->input('rfc');
        $cliente->telefono = $request->input('telefono');
        $cliente->correo_electronico = $request->input('email');
        $cliente->save();

        return redirect('/solicitudServicio')->with('success', 'Cliente guardado correctamente.');
    }
}
